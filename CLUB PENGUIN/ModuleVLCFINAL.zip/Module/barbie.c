#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/vmalloc.h>
#include <linux/slab.h>
#include <linux/fcntl.h>
#include <linux/err.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Ashly");
MODULE_DESCRIPTION("Pinguino_con_frio Video Player");
MODULE_VERSION("1.0");

#define DEVICE_NAME "barbie"

static int major_number;
static int device_open_count = 0;
static char *video_data = NULL;
static size_t video_size = 0;
static size_t buffer_offset = 0;

// Function prototypes
static int barbie_device_open(struct inode *inode, struct file *file);
static int barbie_device_close(struct inode *inode, struct file *file);
static ssize_t barbie_device_read(struct file *filep, char *buffer, size_t len, loff_t *offset);

// Define file operations structure
static struct file_operations fops = {
    .open = barbie_device_open,
    .release = barbie_device_close,
    .read = barbie_device_read,
};

// Open function: Load the video file into memory
static int barbie_device_open(struct inode *inode, struct file *file) {
    struct file *video_file;
    loff_t pos = 0;

    device_open_count++;
    printk(KERN_INFO "Device %s opened. Count: %d\n", DEVICE_NAME, device_open_count);

    // Open video file
    video_file = filp_open("./pinguino_con_frio.mp4", O_RDONLY, 0);
    if (IS_ERR(video_file)) {
        printk(KERN_ERR "Failed to open video file: %ld\n", PTR_ERR(video_file));
        return -ENOENT;
    }

    // Allocate memory for video data
    video_size = video_file->f_inode->i_size;
    video_data = vmalloc(video_size);
    if (!video_data) {
        printk(KERN_ERR "Failed to allocate memory for video data.\n");
        filp_close(video_file, NULL);
        return -ENOMEM;
    }

    // Read video into memory
    kernel_read(video_file, video_data, video_size, &pos);
    filp_close(video_file, NULL);

    buffer_offset = 0;  // Reset read offset
    printk(KERN_INFO "Loaded video of size %zu bytes into memory.\n", video_size);
    return 0;
}

// Close function: Free video memory
static int barbie_device_close(struct inode *inode, struct file *file) {
    printk(KERN_INFO "Device %s closed.\n", DEVICE_NAME);
    if (video_data) {
        vfree(video_data);
        video_data = NULL;
        video_size = 0;
        buffer_offset = 0;
    }
    return 0;
}

// Read function: Send video data to user space
static ssize_t barbie_device_read(struct file *filep, char *buffer, size_t len, loff_t *offset) {
    size_t bytes_to_read;

    if (buffer_offset >= video_size) {
        printk(KERN_INFO "End of video reached.\n");
        return 0;  // EOF
    }

    bytes_to_read = min(len, video_size - buffer_offset);
    if (copy_to_user(buffer, video_data + buffer_offset, bytes_to_read)) {
        printk(KERN_ERR "Failed to send video data to user space.\n");
        return -EFAULT;
    }

    buffer_offset += bytes_to_read;
    return bytes_to_read;
}

// Module initialization
static int __init barbie_init(void) {
    major_number = register_chrdev(0, DEVICE_NAME, &fops);
    if (major_number < 0) {
        printk(KERN_ALERT "Barbie module: Failed to register a major number\n");
        return major_number;
    }

    printk(KERN_INFO "Barbie module loaded! Major number: %d\n", major_number);
    printk(KERN_INFO "Create device file: 'mknod /dev/%s c %d 0'\n", DEVICE_NAME, major_number);
    printk(KERN_INFO "Use VLC to play the video: 'vlc /dev/%s'\n", DEVICE_NAME);
    return 0;
}

// Module cleanup
static void __exit barbie_exit(void) {
    unregister_chrdev(major_number, DEVICE_NAME);
    printk(KERN_INFO "Barbie module unloaded.\n");
}

module_init(barbie_init);
module_exit(barbie_exit);
